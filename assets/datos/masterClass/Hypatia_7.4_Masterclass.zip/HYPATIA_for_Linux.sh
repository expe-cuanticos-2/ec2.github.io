#!/bin/bash

java -jar Hypatia_7.4_Masterclass.jar